# Jeopardy-Style Trivia Game

An academic group project built with Python and Pygame. The game includes a graphical interface, category-based trivia, computer-controlled opponents, scoring, wagering and multiple rounds.

The code is organised into core game logic, question generation and user-interface components.

## Running the project

See USERINSTRUCTIONS_ACKNOWLEDGEMENTS.md for the original setup instructions and asset acknowledgements. From this folder, run:

```bash
python main.py
```

The embedded API key has been removed from this copy. API-based question generation requires your own authorised key, supplied through the AZURE_OPENAI_API_KEY environment variable. Without a key, the game uses its built-in fallback questions.
