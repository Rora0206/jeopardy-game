from __future__ import annotations
import os
import json
import random

from core.question import Question


_FALLBACK_POOL = [
    {
        "clue": "This is the capital city of France.",
        "choices": ["Berlin", "Paris", "Madrid"],
        "correct_index": 1,
        "category": "Geography",
    },
    {
        "clue": "Which planet is known as the Red Planet?",
        "choices": ["Venus", "Jupiter", "Mars"],
        "correct_index": 2,
        "category": "Science",
    },
    {
        "clue": "Who wrote 'Romeo and Juliet'?",
        "choices": ["Charles Dickens", "William Shakespeare", "Mark Twain"],
        "correct_index": 1,
        "category": "Literature",
    },
    {
        "clue": "What is the chemical symbol for gold?",
        "choices": ["Au", "Ag", "Fe"],
        "correct_index": 0,
        "category": "Science",
    },
    {
        "clue": "How many sides does a hexagon have?",
        "choices": ["5", "7", "6"],
        "correct_index": 2,
        "category": "Math",
    },
    {
        "clue": "Which ocean is the largest?",
        "choices": ["Atlantic", "Indian", "Pacific"],
        "correct_index": 2,
        "category": "Geography",
    },
    {
        "clue": "What year did World War II end?",
        "choices": ["1943", "1945", "1947"],
        "correct_index": 1,
        "category": "History",
    },
    {
        "clue": "What is the speed of light (approx.) in km/s?",
        "choices": ["300,000", "150,000", "450,000"],
        "correct_index": 0,
        "category": "Science",
    },
    {
        "clue": "Which element has the atomic number 1?",
        "choices": ["Helium", "Oxygen", "Hydrogen"],
        "correct_index": 2,
        "category": "Science",
    },
    {
        "clue": "How many continents are there on Earth?",
        "choices": ["6", "7", "8"],
        "correct_index": 1,
        "category": "Geography",
    },
    {
        "clue": "What is the largest mammal in the world?",
        "choices": ["Elephant", "Blue Whale", "Giraffe"],
        "correct_index": 1,
        "category": "Nature",
    },
    {
        "clue": "Which country is home to the kangaroo?",
        "choices": ["New Zealand", "South Africa", "Australia"],
        "correct_index": 2,
        "category": "Nature",
    },
]


class QuestionGenerator:
    AZURE_API_KEY = ""
    AZURE_BASE_URL = "https://cuhk-apip.azure-api.net/openai-eus2/openai/v1"
    AZURE_DEPLOYMENT= "gpt-4o"

    def __init__(self, api_key: str = "", model: str = ""):
        self.api_key = api_key or self.AZURE_API_KEY or os.getenv("AZURE_API_KEY", "")
        self.model = model or self.AZURE_DEPLOYMENT
        self.category: str = ""
        self._fallback_pool= list(_FALLBACK_POOL)
        self._openai_available= False
        self._client = None
        if self.api_key:
            try:
                from openai import OpenAI  # type: ignore
                self._client = OpenAI(
                    base_url=self.AZURE_BASE_URL,
                    api_key=self.api_key,
                    default_headers={"api-key": self.api_key},
                )
                self._openai_available= True
            except Exception:
                self._openai_available= False

    def set_category(self, category: str):
        self.category= category

    def reset_used(self):
        pass

    def generate_question(self, difficulty: str = "medium", category: str | None = None) -> Question:
        if self._openai_available:
            try:
                return self._api_generate_one(difficulty, category=category)
            except Exception:
                pass
        return self._fallback_question(category=category)

    def generate_questions_batch(self, count: int, difficulty: str = "medium", category: str | None = None) -> list[Question]:
        if self._openai_available:
            try:
                return self._api_generate_batch(count, difficulty, category=category)
            except Exception as e:
                print(f"[QuestionGenerator] API error: {e}")
        return [self._fallback_question(category=category) for _ in range(count)]

    def generate_column(self, category: str | None = None) -> list[Question]:
        """one api call -> 3 questions: easy, medium, hard (row 0-2 order)."""
        if self._openai_available:
            try:
                return self._api_generate_column(category=category)
            except Exception as e:
                print(f"[QuestionGenerator] column API error: {e}")
        return [self._fallback_question(category=category) for _ in range(3)]

    def _api_generate_column(self, category: str | None = None) -> list[Question]:
        active_category = category or self.category
        category_hint = f" about {active_category}" if active_category else ""
        prompt = (
            f"Generate exactly 3 trivia questions{category_hint}. "
            "The first must be MEDIUM difficulty, the second HARD, the third EXPERT level (very challenging, specific knowledge required). "
            "Return ONLY a valid JSON array with no extra text. Each element must have:\n"
            '  "clue": string,\n'
            '  "choices": array of exactly 3 strings,\n'
            '  "correct_index": integer (0, 1, or 2),\n'
            '  "category": string\n'
            "Example: [{\"clue\":\"...\",\"choices\":[\"A\",\"B\",\"C\"],\"correct_index\":0,\"category\":\"Science\"}]"
        )
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.9,
            timeout=20,
        )
        raw = response.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = "\n".join(raw.split("\n")[1:])
        if raw.endswith("```"):
            raw = raw[: raw.rfind("```")]
        data = json.loads(raw)
        questions = []
        for item in data[:3]:
            q = Question(
                clue=item["clue"],
                choices=item["choices"],
                correct_answer_index=item["correct_index"],
                point_value=0,
                category=item.get("category", active_category or ""),
            )
            questions.append(q)
        while len(questions) < 3:
            questions.append(self._fallback_question(category=category))
        return questions

    def _build_prompt(self, count: int, difficulty: str, category: str | None = None) -> str:
        active_category = category or self.category
        category_hint = f" about {active_category}" if active_category else ""
        return (
            f"Generate {count} unique trivia question(s){category_hint} "
            f"at {difficulty} difficulty level. "
            "Return ONLY a valid JSON array with no extra text. Each element must have:\n"
            '  "clue": string (the question/clue text),\n'
            '  "choices": array of exactly 3 strings (answer options),\n'
            '  "correct_index": integer (0, 1, or 2 - index of correct answer in choices),\n'
            '  "category": string\n'
            "Example: [{\"clue\":\"...\",\"choices\":[\"A\",\"B\",\"C\"],\"correct_index\":0,\"category\":\"Science\"}]"
        )

    def _api_generate_batch(self, count: int, difficulty: str, category: str | None = None) -> list[Question]:
        prompt = self._build_prompt(count, difficulty, category=category)
        response = self._client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.9,
            timeout=15,
        )
        raw = response.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = "\n".join(raw.split("\n")[1:])
        if raw.endswith("```"):
            raw = raw[: raw.rfind("```")]
        data= json.loads(raw)
        questions = []
        for item in data[:count]:
            q = Question(
                clue=item["clue"],
                choices=item["choices"],
                correct_answer_index=item["correct_index"],
                point_value=0,
                category=item.get("category", ""),
            )
            questions.append(q)
        while len(questions) < count:
            questions.append(self._fallback_question(category=category))
        return questions

    def _api_generate_one(self, difficulty: str, category: str | None = None) -> Question:
        return self._api_generate_batch(1, difficulty, category=category)[0]

    def _fallback_question(self, category: str | None = None) -> Question:
        pool = self._fallback_pool
        if category:
            filtered = [q for q in pool if q.get("category", "") == category]
            if filtered:
                pool= filtered
        item= random.choice(pool)
        return Question(
            clue=item["clue"],
            choices=list(item["choices"]),
            correct_answer_index=item["correct_index"],
            point_value=0,
            category=item.get("category", ""),
        )
