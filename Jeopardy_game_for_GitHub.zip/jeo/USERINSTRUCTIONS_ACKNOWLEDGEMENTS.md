## Prerequisites

- Python 3.8 or higher
- pip or conda package manager
- Azure OpenAI API key (for question generation)

## Installation

1. Clone or download this project

2. Install dependencies using either pip or conda:

   **Using pip:**
   ```bash
   pip install -r requirements_pip.txt
   ```

   **Using conda:**
   ```bash
   conda install --file requirements_conda.txt
   ```

3. Set your Azure OpenAI API key as an environment variable:
   ```bash
   # On Windows (PowerShell):
   $env:AZURE_OPENAI_API_KEY="your_api_key_here"
   
   # On Windows (Command Prompt):
   set AZURE_OPENAI_API_KEY=your_api_key_here
   
   # On macOS/Linux:
   export AZURE_OPENAI_API_KEY="your_api_key_here"
   ```

## How to Play

### Starting the Game
```bash
python main.py
```

## Project Structure

```
jeo/
├── main.py                 # Entry point
├── config.py               # Configuration settings
├── requirements_pip.txt    # Pip dependencies
├── requirements_conda.txt  # Conda dependencies
├── api/                    # Question generation
│   └── question_generator.py
├── core/                   # Game logic
│   ├── game.py
│   ├── player.py
│   ├── board.py
│   ├── round.py
│   └── question.py
├── ui/                     # User interface
│   ├── screen_manager.py
│   ├── screens/            # Different game screens
│   └── ui_elements/        # UI components
└── assets/                 # Images and audio
```

## Acknowledgements

- **Background Music**: [Jeopardy Theme Song](https://orangefreesounds.com/jeopardy-theme-song/) by Orange Free Sounds
- **Background Images & UI Elements**: AI-generated assets
- **Question Generation**: Azure OpenAI API
