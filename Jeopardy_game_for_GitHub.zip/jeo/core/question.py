"""
Team A — core/question.py
Immutable data container for a single trivia clue.
"""
import random


class Question:
    def __init__(
        self,
        clue: str,
        choices: list[str],
        correct_answer_index: int,
        point_value: int,
        category: str = "",
        is_daily_double: bool = False,
    ):
        self.clue = clue
        self.choices = list(choices)
        self.correct_answer_index = correct_answer_index
        self.point_value = point_value
        self.category = category
        self.is_daily_double = is_daily_double

    def get_correct_choice(self) -> str:
        """Returns the text of the correct answer."""
        return self.choices[self.correct_answer_index]

    def shuffle_choices(self) -> None:
        """Randomizes choice order and updates correct_answer_index."""
        correct_text = self.get_correct_choice()
        random.shuffle(self.choices)
        self.correct_answer_index = self.choices.index(correct_text)

    def __repr__(self) -> str:
        return f"Question(clue={self.clue!r}, value={self.point_value}, dd={self.is_daily_double})"
