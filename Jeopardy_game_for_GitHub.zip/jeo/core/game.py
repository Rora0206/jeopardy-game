from __future__ import annotations
from core.round import Round
from core.player import Player, HumanPlayer, AIPlayer
from core.question import Question


class Game:
    def __init__(self, players: list[Player], question_generator):
        self.players = players
        self.question_generator= question_generator
        self.current_round: Round | None = None
        self.round_number: int = 0
        self.game_state: str = "menu"

    def start_game(self) -> None:
        self.game_state = "playing"
        self.round_number= 1
        self.current_round = Round("jeopardy", self.players, self.question_generator)
        self.current_round.start_round()

    def get_current_round(self) -> Round | None:
        return self.current_round

    def get_current_player(self) -> Player | None:
        if self.current_round:
            return self.current_round.get_current_player()
        return None

    def advance_to_next_round(self) -> bool:
        if self.round_number == 1:
            self.round_number= 2
            self.current_round = Round("double", self.players, self.question_generator)
            self.current_round.start_round()
            self.game_state = "playing"
            return True
        elif self.round_number == 2:
            eligible = [p for p in self.players if p.get_score() >= 1]
            if not eligible:
                self.game_state = "game_over"
                return False
            self.round_number= 3
            self.current_round = Round("final", self.players, self.question_generator)
            self.current_round.start_round()
            self.game_state = "playing"
            return True
        else:
            self.game_state = "game_over"
            return False

    def handle_tile_selection(self, player: Player, row: int, col: int) -> Question | None:
        if self.current_round is None:
            return None
        question = self.current_round.select_tile(player, row, col)
        if question is None and self.current_round.is_daily_double_active:
            self.game_state = "waiting_for_wager"
            return None
        if question is None:
            return None
        self.game_state = "answering_question"
        return question

    def handle_wager(self, player: Player, wager_amount: int) -> bool:
        # validate and record wager for daily double or final
        if self.current_round is None:
            return False
        board = self.current_round.board
        if board is not None:
            remaining_values = [t.point_value for t in board.get_unanswered_tiles()]
            max_board = max(remaining_values) if remaining_values else 0
        else:
            max_board= 0
        if self.current_round.round_type == "final":
            max_available = player.get_score()
        else:
            max_available = max(player.get_score(), max_board)
        if not self.validate_wager(wager_amount, player.get_score(), max_available):
            return False
        self.current_round.set_wager(wager_amount)
        self.game_state = "answering_question"
        return True

    def validate_wager(self, wager: int, player_score:int, max_available: int):
        return 5 <= wager <= max_available

    def handle_answer(self, player: Player, answer_idx: int) -> bool:
        if self.current_round is None:
            return False
        correct = self.current_round.answer_question(player, answer_idx)
        # let ai take a turn after human answers (non-final rounds)
        if self.current_round.round_type in ("jeopardy", "double"):
            self._run_ai_turns_once()
        if self.current_round.is_complete():
            if self.current_round.round_type == "final":
                self.current_round.process_ai_parallel_turns()
            if self.round_number < 3:
                self.game_state = "round_transition"
            else:
                self.game_state = "game_over"
        else:
            self.game_state = "playing"
        return correct

    def _run_ai_turns_once(self) -> None:
        # each ai picks from its own board, independent of human's board
        if self.current_round is None:
            return
        for ai in [p for p in self.players if not p.is_player_human()]:
            ai_board = self.current_round._ai_boards.get(ai)
            if ai_board is None:
                continue
            available = ai_board.get_unanswered_tiles()
            if not available:
                continue
            tile = ai.select_tile(available)
            if tile is None:
                continue
            question = tile.get_question()
            ai_board.mark_tile_answered(tile.row, tile.col)
            if tile.is_daily_double:
                remaining = ai_board.get_unanswered_tiles()
                max_board = max((t.point_value for t in remaining), default=0)
                max_wager = max(ai.get_score(), max_board)
                wager = ai.decide_wager(ai.get_score(), max_wager)
                points = max(5, min(wager, max_wager))
            else:
                points = question.point_value
            ans = ai.answer_question(question)
            if ans == question.correct_answer_index:
                ai.add_points(points)
            else:
                ai.add_points(-points)

    def run_ai_turn(self) -> None:
        # executes a full ai turn; called by game loop when current player is ai
        if self.current_round is None or self.game_state != "playing":
            return
        player = self.get_current_player()
        if player.is_player_human():
            return
        if self.current_round.round_type == "final":
            score= player.get_score()
            max_wager = score if score >= 1 else 5
            wager = player.decide_wager(score, max_wager)
            self.handle_wager(player, max(5, min(wager, max_wager)))
            answer = player.answer_question(self.current_round.current_question)
            self.handle_answer(player, answer)
            return
        board = self.current_round.board
        if board is None:
            return
        available = board.get_unanswered_tiles()
        if not available:
            return
        tile = player.select_tile(available)
        question = self.handle_tile_selection(player, tile.row, tile.col)
        if self.game_state == "waiting_for_wager":
            remaining = board.get_unanswered_tiles()
            max_board = max((t.point_value for t in remaining), default=0)
            max_wager = max(player.get_score(), max_board)
            wager = player.decide_wager(player.get_score(), max_wager)
            wager= max(5, min(wager, max_wager))
            self.handle_wager(player, wager)
            question = self.current_round.current_question
        if question is not None:
            answer = player.answer_question(question)
            self.handle_answer(player, answer)
        elif self.game_state == "answering_question":
            q = self.current_round.current_question
            if q is not None:
                answer = player.answer_question(q)
                self.handle_answer(player, answer)

    def is_game_over(self) -> bool:
        return self.game_state == "game_over" or self.round_number > 3

    def get_winner(self) -> Player:
        return max(self.players, key=lambda p: p.get_score())

    def get_final_rankings(self) -> list[Player]:
        return sorted(self.players, key=lambda p: p.get_score(), reverse=True)

    def reset_game(self) -> None:
        for p in self.players:
            p.reset_score()
        self.game_state= "menu"
        self.round_number= 0
        self.current_round = None
        if hasattr(self.question_generator, "reset_used"):
            self.question_generator.reset_used()

    def get_game_state(self) -> str:
        return self.game_state

    def get_round_number(self) -> int:
        return self.round_number

    def get_round_name(self) -> str:
        names = {1: "Jeopardy!", 2: "Double Jeopardy!", 3: "Final Jeopardy!"}
        return names.get(self.round_number, "")
