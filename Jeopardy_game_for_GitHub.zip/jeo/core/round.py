from __future__ import annotations
import random
from core.board import Board
from core.question import Question


JEOPARDY_VALUES = {
    (0, 0): 200, (0, 1): 200, (0, 2): 200,
    (1, 0): 400, (1, 1): 400, (1, 2): 400,
    (2, 0): 600, (2, 1): 600, (2, 2): 600,
}
DOUBLE_VALUES = {
    (0, 0): 400, (0, 1): 400, (0, 2): 400,
    (1, 0): 800, (1, 1): 800, (1, 2): 800,
    (2, 0): 1200, (2, 1): 1200, (2, 2): 1200,
}

DEFAULT_CATEGORIES = [
    "Science", "History", "Geography",
    "Literature", "Math", "Nature",
    "Sports", "Music", "Movies",
]

# fixed question pool used for ai boards (no api calls)
_AI_POOL = [
    {"clue": "What gas do plants absorb from the air?", "choices": ["Oxygen", "Nitrogen", "Carbon Dioxide"], "correct_index": 2, "category": "Science"},
    {"clue": "What is 12 multiplied by 12?", "choices": ["124", "144", "132"], "correct_index": 1, "category": "Math"},
    {"clue": "Which country has the most natural lakes?", "choices": ["Russia", "Canada", "USA"], "correct_index": 1, "category": "Geography"},
    {"clue": "Who painted the Mona Lisa?", "choices": ["Van Gogh", "Picasso", "Leonardo da Vinci"], "correct_index": 2, "category": "History"},
    {"clue": "What is the hardest natural substance on Earth?", "choices": ["Gold", "Diamond", "Iron"], "correct_index": 1, "category": "Science"},
    {"clue": "In which year did the Titanic sink?", "choices": ["1912", "1905", "1920"], "correct_index": 0, "category": "History"},
    {"clue": "How many strings does a standard guitar have?", "choices": ["4", "6", "8"], "correct_index": 1, "category": "Music"},
    {"clue": "What is the square root of 144?", "choices": ["11", "12", "13"], "correct_index": 1, "category": "Math"},
    {"clue": "Which bird is the fastest on foot?", "choices": ["Penguin", "Ostrich", "Emu"], "correct_index": 1, "category": "Nature"},
    {"clue": "What element does 'O' represent on the periodic table?", "choices": ["Gold", "Osmium", "Oxygen"], "correct_index": 2, "category": "Science"},
    {"clue": "Who wrote '1984'?", "choices": ["Aldous Huxley", "George Orwell", "Ray Bradbury"], "correct_index": 1, "category": "Literature"},
    {"clue": "Which sport uses a shuttlecock?", "choices": ["Tennis", "Badminton", "Squash"], "correct_index": 1, "category": "Sports"},
    {"clue": "What is the capital of Japan?", "choices": ["Kyoto", "Osaka", "Tokyo"], "correct_index": 2, "category": "Geography"},
    {"clue": "How many bones are in the adult human body?", "choices": ["206", "180", "215"], "correct_index": 0, "category": "Science"},
    {"clue": "Which movie won the first Academy Award for Best Picture?", "choices": ["Wings", "Sunrise", "The Jazz Singer"], "correct_index": 0, "category": "Movies"},
    {"clue": "What is 15% of 200?", "choices": ["25", "30", "35"], "correct_index": 1, "category": "Math"},
    {"clue": "Which planet has the most moons?", "choices": ["Jupiter", "Saturn", "Uranus"], "correct_index": 1, "category": "Science"},
    {"clue": "In what country did the Olympics originate?", "choices": ["Italy", "Greece", "Egypt"], "correct_index": 1, "category": "History"},
]


class Round:
    def __init__(self, round_type: str, players: list, question_generator):
        self.round_type= round_type
        self.players = players
        self.question_generator = question_generator

        self.board: Board | None = None
        self.current_player_index: int = 0
        self.current_question: Question | None = None
        self.current_wager: int = 0
        self._is_daily_double_active: bool = False
        self._final_jeopardy_answered: bool = False
        self._final_eligible_players: list = []
        self.human_player = None
        self._ai_boards: dict = {}
        self._final_ai_processed: bool = False

    def start_round(self) -> None:
        self.human_player = next((p for p in self.players if p.is_player_human()), None)
        if self.human_player is None and self.players:
            self.human_player = self.players[0]
        self.current_player_index = self.players.index(self.human_player) if self.human_player else 0
        self._ai_boards = {}
        self._final_ai_processed= False

        if self.round_type == "jeopardy":
            point_values = JEOPARDY_VALUES
            self.board = Board(point_values, 1)
            categories = self._pick_column_categories()
            self._assign_questions_by_column(self.board, point_values, categories)
            for p in self.players:
                if not p.is_player_human():
                    self._ai_boards[p]= self._build_ai_board_from_pool(point_values, 1)

        elif self.round_type == "double":
            point_values = DOUBLE_VALUES
            self.board = Board(point_values, 2)
            categories = self._pick_column_categories()
            self._assign_questions_by_column(self.board, point_values, categories)
            for p in self.players:
                if not p.is_player_human():
                    self._ai_boards[p]= self._build_ai_board_from_pool(point_values, 2)

        elif self.round_type == "final":
            self.board = None
            self._final_eligible_players = [p for p in self.players if p.get_score() >= 1]
            q = self.question_generator.generate_question(difficulty="expert")
            q.point_value= 0
            self.current_question = q

    def _assign_questions_to_board(self, questions: list[Question], point_values: dict, board: Board | None = None) -> None:
        target = board or self.board
        if target is None:
            return
        idx= 0
        for r in range(3):
            for c in range(3):
                tile = target.get_tile(r, c)
                if idx < len(questions):
                    q = questions[idx]
                    q.point_value = point_values.get((r, c), q.point_value)
                    q.is_daily_double = tile.is_daily_double
                    tile.set_question(q)
                    idx += 1

    def _build_ai_board_from_pool(self, point_values: dict, multiplier: int) -> Board:
        board = Board(point_values, multiplier)
        pool = list(_AI_POOL)
        random.shuffle(pool)
        idx = 0
        for r in range(3):
            for c in range(3):
                tile = board.get_tile(r, c)
                if tile is None:
                    continue
                entry = pool[idx % len(pool)]
                idx += 1
                q = Question(
                    clue=entry["clue"],
                    choices=list(entry["choices"]),
                    correct_answer_index=entry["correct_index"],
                    point_value=point_values.get((r, c), 0),
                    category=entry["category"],
                )
                q.is_daily_double = tile.is_daily_double
                tile.set_question(q)
        return board

    def _pick_column_categories(self) -> list[str]:
        choices = list(DEFAULT_CATEGORIES)
        random.shuffle(choices)
        return choices[:3]

    def _assign_questions_by_column(self, board: Board, point_values: dict, categories: list[str]) -> None:
        for c in range(3):
            category = categories[c] if c < len(categories) else ""
            # one api call returns [easy, medium, hard] for this column
            questions = self.question_generator.generate_column(category=category)
            for r in range(3):
                tile = board.get_tile(r, c)
                if tile is None:
                    continue
                q = questions[r] if r < len(questions) else self.question_generator.generate_question(category=category)
                q.point_value= point_values.get((r, c), q.point_value)
                q.is_daily_double = tile.is_daily_double
                if category:
                    q.category = category
                tile.set_question(q)

    def get_current_player(self):
        return self.human_player or self.players[self.current_player_index]

    def select_tile(self, player, row: int, col: int) -> Question | None:
        if self.board is None:
            return None
        tile = self.board.get_tile(row, col)
        if tile is None or tile.is_answered:
            return None
        self.current_question = tile.get_question()
        if tile.is_daily_double:
            self._is_daily_double_active= True
            self.current_wager= 0
            self.board.mark_tile_answered(row, col)
            return None
        self.board.mark_tile_answered(row, col)
        self._is_daily_double_active = False
        return self.current_question

    def set_wager(self, amount: int) -> bool:
        self.current_wager = amount
        return True

    def answer_question(self, player, answer_idx: int) -> bool:
        if self.current_question is None:
            return False
        correct = (answer_idx == self.current_question.correct_answer_index)
        if self._is_daily_double_active or self.round_type == "final":
            points = self.current_wager
        else:
            points = self.current_question.point_value
        if correct:
            player.add_points(points)
        else:
            player.add_points(-points)
        if self.round_type == "final":
            self._final_jeopardy_answered = True
        else:
            self._is_daily_double_active = False
            self.current_wager= 0
        return correct

    def get_next_player(self):
        self.current_player_index = (self.current_player_index + 1) % len(self.players)
        return self.players[self.current_player_index]

    def is_complete(self) -> bool:
        if self.round_type == "final":
            return self._final_jeopardy_answered
        return self.board is not None and self.board.is_complete()

    def get_board_state(self) -> dict:
        return {
            "tiles": self.board.get_all_tiles() if self.board else [],
            "answered_count": self.board.answered_count if self.board else 0,
            "total_tiles": 9,
            "round_type": self.round_type,
        }

    def get_eligible_players_final(self) -> list:
        return [p for p in self.players if p.get_score() >= 1]

    def process_ai_parallel_turns(self) -> None:
        ai_players = [p for p in self.players if not p.is_player_human()]
        if not ai_players:
            return
        if self.round_type in ("jeopardy", "double"):
            for ai in ai_players:
                board = self._ai_boards.get(ai)
                if board is None:
                    continue
                available = board.get_unanswered_tiles()
                if not available:
                    continue
                tile = ai.select_tile(available)
                if tile is None:
                    continue
                question = tile.get_question()
                board.mark_tile_answered(tile.row, tile.col)
                if tile.is_daily_double:
                    remaining = board.get_unanswered_tiles()
                    max_board = max((t.point_value for t in remaining), default=0)
                    max_wager = max(ai.get_score(), max_board)
                    wager = ai.decide_wager(ai.get_score(), max_wager)
                    points= max(5, min(wager, max_wager))
                else:
                    points = question.point_value
                answer_idx = ai.answer_question(question)
                if answer_idx == question.correct_answer_index:
                    ai.add_points(points)
                else:
                    ai.add_points(-points)
        elif self.round_type == "final":
            if self._final_ai_processed or self.current_question is None:
                return
            for ai in ai_players:
                if ai.get_score() < 1:
                    continue
                max_wager = ai.get_score()
                wager = ai.decide_wager(ai.get_score(), max_wager)
                wager= max(5, min(wager, max_wager))
                answer_idx = ai.answer_question(self.current_question)
                if answer_idx == self.current_question.correct_answer_index:
                    ai.add_points(wager)
                else:
                    ai.add_points(-wager)
            self._final_ai_processed = True

    @property
    def is_daily_double_active(self) -> bool:
        return self._is_daily_double_active
