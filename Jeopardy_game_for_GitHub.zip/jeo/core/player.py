from __future__ import annotations
import random


class Player:
    def __init__(self, name: str, is_human: bool = False):
        self.name = name
        self.is_human= is_human
        self.score: int = 0

    def add_points(self, amount: int) -> None:
        self.score += amount

    def get_score(self) -> int:
        return self.score

    def reset_score(self) -> None:
        self.score= 0

    def get_name(self) -> str:
        return self.name

    def is_player_human(self) -> bool:
        return self.is_human

    def __repr__(self) -> str:
        return f"Player({self.name!r}, score={self.score})"


class HumanPlayer(Player):
    def __init__(self, name: str = "Human"):
        super().__init__(name, is_human=True)


class AIPlayer(Player):
    def __init__(self, name: str = "AI", difficulty: float = 0.7):
        super().__init__(name, is_human=False)
        self.difficulty= difficulty  # 0.0-1.0 correct probability

    def select_tile(self, available_tiles: list) -> object:
        # 70% pick highest value, else random
        if not available_tiles:
            return None
        if random.random() < 0.7:
            return max(available_tiles, key=lambda t: t.point_value)
        return random.choice(available_tiles)

    def decide_wager(self, current_score: int, max_wager: int) -> int:
        # wager 30-70% of score, clamped to [5, max_wager]
        if current_score <= 0:
            return min(5, max_wager)
        low = int(current_score * 0.3)
        high= int(current_score * 0.7)
        if low > high:
            low, high = high, low
        wager = random.randint(low, high) if low < high else low
        return max(5, min(wager, max_wager))

    def answer_question(self, question: object) -> int:
        # returns index 0-2; correct with probability = difficulty
        if random.random() < self.difficulty:
            return question.correct_answer_index
        wrong = [i for i in range(3) if i != question.correct_answer_index]
        return random.choice(wrong)
