"""
Team A — core/board.py
Board and Tile classes; manages 3×3 grid with Daily Double placement.
"""
import random
from core.question import Question


class Tile:
    def __init__(self, row: int, col: int, point_value: int, is_daily_double: bool = False):
        self.row = row
        self.col = col
        self.point_value = point_value
        self.is_daily_double = is_daily_double
        self.question: Question | None = None
        self.is_answered: bool = False

    def mark_answered(self) -> None:
        self.is_answered = True

    def get_question(self) -> Question:
        return self.question

    def set_question(self, question: Question) -> None:
        self.question = question

    def get_id(self) -> str:
        return f"{self.row}_{self.col}"

    def __repr__(self) -> str:
        return f"Tile({self.row},{self.col}, ${self.point_value}, dd={self.is_daily_double}, answered={self.is_answered})"


class Board:
    def __init__(self, point_values: dict, num_daily_doubles: int):
        """
        point_values: dict mapping (row, col) -> int
        num_daily_doubles: number of Daily Double tiles to place
        """
        self.point_values = point_values
        self.answered_count: int = 0
        self.daily_double_positions: set = set()

        # Build 3×3 grid
        self.tiles: list[list[Tile]] = [
            [Tile(r, c, point_values.get((r, c), 0)) for c in range(3)]
            for r in range(3)
        ]

        # Randomly place Daily Doubles
        all_positions = [(r, c) for r in range(3) for c in range(3)]
        dd_positions = random.sample(all_positions, min(num_daily_doubles, 9))
        for r, c in dd_positions:
            self.tiles[r][c].is_daily_double = True
            self.daily_double_positions.add((r, c))

    def get_tile(self, row: int, col: int) -> Tile | None:
        if 0 <= row < 3 and 0 <= col < 3:
            return self.tiles[row][col]
        return None

    def get_unanswered_tiles(self) -> list[Tile]:
        return [
            self.tiles[r][c]
            for r in range(3)
            for c in range(3)
            if not self.tiles[r][c].is_answered
        ]

    def get_all_tiles(self) -> list[list[Tile]]:
        return self.tiles

    def mark_tile_answered(self, row: int, col: int) -> bool:
        tile = self.get_tile(row, col)
        if tile is None or tile.is_answered:
            return False
        tile.mark_answered()
        self.answered_count += 1
        return True

    def is_complete(self) -> bool:
        return self.answered_count == 9

    def reset(self) -> None:
        for r in range(3):
            for c in range(3):
                self.tiles[r][c].is_answered = False
        self.answered_count = 0
