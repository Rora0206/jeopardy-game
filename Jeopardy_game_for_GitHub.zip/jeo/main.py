import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pygame
import config
from core.game import Game
from core.player import HumanPlayer, AIPlayer
from api.question_generator import QuestionGenerator
from ui.screen_manager import ScreenManager


def main():
    pygame.init()
    pygame.display.set_caption(config.WINDOW_TITLE)
    screen = pygame.display.set_mode((config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
    clock= pygame.time.Clock()

    api_key = os.getenv("AZURE_OPENAI_API_KEY", "")
    question_gen = QuestionGenerator(api_key=api_key)

    players = [
        HumanPlayer(name="You"),
        AIPlayer(name="AI1", difficulty=0.5),
        AIPlayer(name="AI2", difficulty=0.7),
    ]

    game= Game(players, question_gen)
    screen_manager = ScreenManager(game)

    try:
        pygame.mixer.music.load(config.BGM_PATH)
        pygame.mixer.music.set_volume(0.5)
        pygame.mixer.music.play(-1)
    except pygame.error as e:
        print(f"Warning: Could not load background music: {e}")

    running= True
    while running:
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running= False
        screen_manager.update(events)
        screen_manager.draw(screen)
        pygame.display.flip()
        clock.tick(config.FPS)
    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
