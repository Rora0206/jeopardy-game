"""
ui/ui_elements/volume_slider.py
A volume slider rendered in the bottom-right corner.
Drag the knob or click anywhere on the track to set volume 
"""
import pygame
import config


def _sf(size, bold=False):
    try:    return pygame.font.SysFont(config.FONT_FAMILY, size, bold=bold)
    except: return pygame.font.Font(None, size)


class VolumeSlider:
    TRACK_W  = 100
    TRACK_H  = 6
    KNOB_R   = 7
    ICON_GAP = 6          # gap between icon and track
    MARGIN_R = 16         # distance from right edge
    MARGIN_B = 18         # distance from bottom edge

    def __init__(self, initial_volume: float = 0.4):
        self._volume   = max(0.0, min(1.0, initial_volume))
        self._dragging = False
        self._font     = _sf(config.FONT_SIZE_TINY)
        self._visible  = True

        # Pre-render icon label (static text)
        self._icon_surf = self._font.render("VOL", True, (140, 140, 170))

        # Compute geometry (anchored bottom-right)
        self._layout()

    
    def _layout(self):
        icon_w = self._icon_surf.get_width()
        total_w = icon_w + self.ICON_GAP + self.TRACK_W + self.KNOB_R
        right  = config.SCREEN_WIDTH  - self.MARGIN_R
        bottom = config.SCREEN_HEIGHT - self.MARGIN_B

        self._icon_rect = self._icon_surf.get_rect(
            right=right - self.TRACK_W - self.ICON_GAP,
            centery=bottom)

        self._track_rect = pygame.Rect(
            right - self.TRACK_W,
            bottom - self.TRACK_H // 2,
            self.TRACK_W,
            self.TRACK_H,
        )
        self._update_knob()

    def _update_knob(self):
        kx = int(self._track_rect.x + self._volume * self._track_rect.width)
        ky = self._track_rect.centery
        self._knob_pos = (kx, ky)

    #  volume helpers
    def _set_volume_from_x(self, mx: int):
        tx = self._track_rect.x
        tw = self._track_rect.width
        self._volume = max(0.0, min(1.0, (mx - tx) / tw))
        self._update_knob()
        try:
            pygame.mixer.music.set_volume(self._volume)
        except Exception:
            pass

    @property
    def volume(self) -> float:
        return self._volume

    #  event handling 
    def update(self, events: list):
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                # hit-test
                kx, ky = self._knob_pos
                dist2  = (e.pos[0]-kx)**2 + (e.pos[1]-ky)**2
                if dist2 <= (self.KNOB_R + 4)**2 or self._track_rect.inflate(0, 14).collidepoint(e.pos):
                    self._dragging = True
                    self._set_volume_from_x(e.pos[0])

            elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                self._dragging = False

            elif e.type == pygame.MOUSEMOTION and self._dragging:
                self._set_volume_from_x(e.pos[0])

    #  drawing 
    def draw(self, surface: pygame.Surface):
        if not self._visible:
            return

        # semi-transparent pill background
        pad = 6
        bg_rect = pygame.Rect(
            self._icon_rect.left - pad,
            self._track_rect.centery - self.KNOB_R - pad,
            (self._track_rect.right + self.KNOB_R + pad) - (self._icon_rect.left - pad),
            (self.KNOB_R + pad) * 2,
        )
        bg_surf = pygame.Surface((bg_rect.width, bg_rect.height), pygame.SRCALPHA)
        bg_surf.fill((10, 10, 40, 160))
        pygame.draw.rect(bg_surf, (60, 60, 100, 180), bg_surf.get_rect(),
                         1, border_radius=bg_rect.height // 2)
        surface.blit(bg_surf, bg_rect.topleft)

        #  icon
        surface.blit(self._icon_surf, self._icon_rect)

        # track background
        pygame.draw.rect(surface, (50, 50, 80), self._track_rect, border_radius=3)

        # filled portion
        filled = pygame.Rect(
            self._track_rect.x,
            self._track_rect.y,
            int(self._volume * self._track_rect.width),
            self._track_rect.height,
        )
        if filled.width > 0:
            pygame.draw.rect(surface, config.COLOR_TEXT_GOLD, filled, border_radius=3)

        kx, ky = self._knob_pos
        pygame.draw.circle(surface, config.COLOR_TEXT_GOLD, (kx, ky), self.KNOB_R)
        pygame.draw.circle(surface, (255, 255, 200), (kx, ky), self.KNOB_R - 2)
        pygame.draw.circle(surface, (180, 140, 0),  (kx, ky), self.KNOB_R, 1)

        if self._dragging:
            pct_s = self._font.render(f"{int(self._volume*100)}%", True, config.COLOR_TEXT_GOLD)
            surface.blit(pct_s, (kx - pct_s.get_width()//2,
                                  ky - self.KNOB_R - pct_s.get_height() - 2))
