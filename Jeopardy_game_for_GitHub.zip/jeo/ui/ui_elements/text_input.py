"""
Team C — ui/ui_elements/text_input.py
Stylized numeric text input with glow active state and blinking cursor.
"""
import pygame
import config


def _safe_font(family, size, bold=False):
    try:
        return pygame.font.SysFont(family, size, bold=bold)
    except Exception:
        return pygame.font.Font(None, size)


class TextInput:
    def __init__(self, x, y, width, height, max_chars=6):
        self.rect      = pygame.Rect(x, y, width, height)
        self.text      = ""
        self.is_active = True
        self.max_chars = max_chars
        self._font     = _safe_font(config.FONT_FAMILY, config.FONT_SIZE_LARGE, bold=True)
        self._cursor_visible = True
        self._cursor_timer   = 0.0

        # build static surfaces
        gw, gh = width + 12, height + 12
        self._glow_surf = pygame.Surface((gw, gh), pygame.SRCALPHA)
        pygame.draw.rect(self._glow_surf, (255, 215, 0, 35),
                         self._glow_surf.get_rect(), border_radius=10)

        self._hl_surf = pygame.Surface((width - 8, 2), pygame.SRCALPHA)
        self._hl_surf.fill((255, 255, 255, 40))

    def handle_key(self, event):
        if event.type != pygame.KEYDOWN or not self.is_active:
            return None
        if event.key == pygame.K_BACKSPACE:
            self.text = self.text[:-1]
        elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            return self.text
        elif event.unicode.isdigit() and len(self.text) < self.max_chars:
            self.text += event.unicode
        return None

    def get_text(self):
        return self.text

    def clear(self):
        self.text = ""

    def update(self, dt):
        self._cursor_timer += dt
        if self._cursor_timer >= 0.5:
            self._cursor_visible = not self._cursor_visible
            self._cursor_timer   = 0.0

    def draw(self, surface):
        # glow behind active input
        if self.is_active:
            surface.blit(self._glow_surf, (self.rect.x - 6, self.rect.y - 6))

        bg = config.COLOR_INPUT_ACTIVE if self.is_active else config.COLOR_INPUT_BG
        pygame.draw.rect(surface, bg, self.rect, border_radius=8)
        border_col = config.COLOR_BORDER if self.is_active else (100, 100, 130)
        pygame.draw.rect(surface, border_col, self.rect, 2, border_radius=8)

        # highlight line at top
        surface.blit(self._hl_surf, (self.rect.x + 4, self.rect.y + 3))

        display = self.text + ("|" if self.is_active and self._cursor_visible else " ")
        text_surf = self._font.render(display, True, config.COLOR_TEXT_GOLD)
        text_rect = text_surf.get_rect(midleft=(self.rect.left + 14, self.rect.centery))
        surface.blit(text_surf, text_rect)
