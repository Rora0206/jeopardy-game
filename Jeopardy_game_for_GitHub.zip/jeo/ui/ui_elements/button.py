"""
Team C — ui/ui_elements/button.py
Reusable UIButton with gradient fill, glow hover effect, and gold border.
"""
import pygame
import config


def _safe_font(family, size, bold=False):
    try:
        return pygame.font.SysFont(family, size, bold=bold)
    except Exception:
        return pygame.font.Font(None, size)


def _draw_gradient_rect(surface, rect, color_top, color_bot, radius=10):
    #   Draw a vertical-gradient rounded rectangle onto surface."""
    tmp = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    for y in range(rect.height):
        t = y / max(rect.height - 1, 1)
        r = int(color_top[0] + (color_bot[0] - color_top[0]) * t)
        g = int(color_top[1] + (color_bot[1] - color_top[1]) * t)
        b = int(color_top[2] + (color_bot[2] - color_top[2]) * t)
        pygame.draw.line(tmp, (r, g, b, 230), (0, y), (rect.width, y))
    # mask to rounded rect
    mask = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    mask.fill((0, 0, 0, 0))
    pygame.draw.rect(mask, (255, 255, 255, 255), mask.get_rect(), border_radius=radius)
    tmp.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    surface.blit(tmp, rect.topleft)


class UIButton:
    def __init__(self, x, y, width, height, text, callback, font_size=None):
        if font_size is None:
            font_size = config.FONT_SIZE_MEDIUM
        self.rect     = pygame.Rect(x, y, width, height)
        self.text     = text
        self.callback = callback
        self.is_hovered = False
        self._font = _safe_font(config.FONT_FAMILY, font_size, bold=True)

        gw, gh = width + 8, height + 8
        self._glow_surf = pygame.Surface((gw, gh), pygame.SRCALPHA)
        pygame.draw.rect(self._glow_surf, (255, 215, 0, 60),
                         self._glow_surf.get_rect(),
                         border_radius=config.BUTTON_RADIUS + 4)

    def handle_click(self, mouse_pos):
        if self.rect.collidepoint(mouse_pos):
            if self.callback:
                self.callback()
            return True
        return False

    def is_mouse_over(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)

    def update(self, mouse_pos):
        self.is_hovered = self.is_mouse_over(mouse_pos)

    @staticmethod
    def _sanitize(text: str) -> str:
        replacements = {
            "\u2018": "'", "\u2019": "'",
            "\u201c": '"', "\u201d": '"',
            "\u2013": "-", "\u2014": "-",
            "\u2026": "...",
        }
        for src, dst in replacements.items():
            text = text.replace(src, dst)
        text = text.encode("ascii", errors="replace").decode("ascii").replace("?", " ")
        return text

    def draw(self, surface):
        if self.is_hovered:
            top = (70, 70, 220)
            bot = (30, 30, 160)
            surface.blit(self._glow_surf, (self.rect.x - 4, self.rect.y - 4))
        else:
            top = (30, 30, 160)
            bot = (15, 15, 100)

        _draw_gradient_rect(surface, self.rect, top, bot, radius=config.BUTTON_RADIUS)

        # border so annoying
        border_color = config.COLOR_BORDER if self.is_hovered else (180, 150, 0)
        pygame.draw.rect(surface, border_color, self.rect,
                         2, border_radius=config.BUTTON_RADIUS)

        # top highlight line
        hl = pygame.Surface((self.rect.width - 8, 2), pygame.SRCALPHA)
        hl.fill((255, 255, 255, 50))
        surface.blit(hl, (self.rect.x + 4, self.rect.y + 3))

        label = self._sanitize(self.text)
        text_surf = self._font.render(label, True, config.COLOR_BUTTON_TEXT)
        text_rect = text_surf.get_rect(center=self.rect.center)
        # subtle shadow
        shadow = self._font.render(label, True, (0, 0, 0))
        surface.blit(shadow, text_rect.move(1, 1))
        surface.blit(text_surf, text_rect)
