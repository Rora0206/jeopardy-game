"""
Team C — ui/ui_elements/board_tile.py
Board tile with texture image, hover glow, answered state.
"""
import pygame
import config


def _safe_font(family, size, bold=False):
    try:
        return pygame.font.SysFont(family, size, bold=bold)
    except Exception:
        return pygame.font.Font(None, size)


class BoardTileUI:
    _textures: dict = {}

    @classmethod
    def _load_textures(cls, tw, th):
        key = (tw, th)
        if key not in cls._textures:
            def _load(path):
                try:
                    img = pygame.image.load(path).convert_alpha()
                    return pygame.transform.smoothscale(img, (tw, th))
                except Exception:
                    surf = pygame.Surface((tw, th), pygame.SRCALPHA)
                    surf.fill((30, 30, 160, 230))
                    return surf
            cls._textures[key] = {
                "normal": _load(config.IMG_TILE_NORMAL),
                "hover":  _load(config.IMG_TILE_HOVER),
                "done":   _load(config.IMG_TILE_DONE),
                "daily":  _load(config.IMG_TILE_DAILY),
            }
        return cls._textures[key]

    def __init__(self, tile, x, y, width, height):
        self.tile      = tile
        self.rect      = pygame.Rect(x, y, width, height)
        self.is_hovered = False
        self._tex      = self._load_textures(width, height)
        self._font_val = _safe_font(config.FONT_FAMILY, config.FONT_SIZE_LARGE, bold=True)
        self._font_dd  = _safe_font(config.FONT_FAMILY, config.FONT_SIZE_SMALL, bold=True)
        self._font_chk = _safe_font(config.FONT_FAMILY, config.FONT_SIZE_MEDIUM)

        gw, gh = width + 10, height + 10
        self._glow_surf = pygame.Surface((gw, gh), pygame.SRCALPHA)
        pygame.draw.rect(self._glow_surf, (255, 215, 0, 50),
                         self._glow_surf.get_rect(), border_radius=10)

    def handle_click(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos) and not self.tile.is_answered

    def is_mouse_over(self, mouse_pos):
        return self.rect.collidepoint(mouse_pos)

    def update(self, tile=None):
        if tile is not None:
            self.tile = tile

    def update_hover(self, mouse_pos):
        self.is_hovered = self.is_mouse_over(mouse_pos) and not self.tile.is_answered

    def draw(self, surface):
        if self.tile.is_answered:
            tex = self._tex["done"]
        elif self.is_hovered:
            tex = self._tex["hover"]
            surface.blit(self._glow_surf, (self.rect.x - 5, self.rect.y - 5))
        else:
            tex = self._tex["normal"]

        surface.blit(tex, self.rect.topleft)
        pygame.draw.rect(surface, config.COLOR_BORDER, self.rect, 2, border_radius=8)

        if not self.tile.is_answered:
            val_txt = f"${self.tile.point_value}"
            shadow  = self._font_val.render(val_txt, True, (0, 0, 0))
            val_s   = self._font_val.render(val_txt, True, config.COLOR_TEXT_GOLD)
            r = val_s.get_rect(center=self.rect.center)
            surface.blit(shadow, r.move(2, 2))
            surface.blit(val_s, r)
        else:
            chk = self._font_chk.render("✓", True, (80, 80, 80))
            surface.blit(chk, chk.get_rect(center=self.rect.center))
