"""
Team B — ui/screen_manager.py
manages screen transitions and the active screen
gateway between screens and the Game instance
"""
import pygame
from core.game import Game
from ui.ui_elements.volume_slider import VolumeSlider


class ScreenManager:
    def __init__(self, game: Game):
        self.game = game
        self.screens: dict = {}
        self.current_screen = None
        self._volume_slider = VolumeSlider(initial_volume=0.4)
        self._initialize_screens()

    def _initialize_screens(self) :

        from ui.screens.menu_screen import MenuScreen
        self.screens["menu"] = MenuScreen(self)
        self.current_screen = self.screens["menu"]

    def _get_or_create_screen(self, screen_name: str):
        if screen_name not in self.screens:
            from ui.screens.board_screen import BoardScreen
            from ui.screens.question_screen import QuestionScreen
            from ui.screens.wager_screen import WagerScreen
            from ui.screens.game_over_screen import GameOverScreen
            builders = {
                "board":    lambda: BoardScreen(self),
                "question": lambda: QuestionScreen(self),
                "wager":    lambda: WagerScreen(self),
                "gameover": lambda: GameOverScreen(self),
            }
            if screen_name in builders:
                self.screens[screen_name] = builders[screen_name]()
        return self.screens.get(screen_name)

    def switch_to(self, screen_name: str, **kwargs):
        #switch to named screen pass kwargs to on_enter() if defined."""
        screen = self._get_or_create_screen(screen_name)
        if screen is None:
            return
        if hasattr(screen, "on_enter"):
            screen.on_enter(**kwargs)
        self.current_screen = screen


    def get_current_screen(self):
        return self.current_screen

    def update(self, events: list[pygame.event.Event]):
        self._volume_slider.update(events)
        if self.current_screen:
            self.current_screen.update(events)

    def draw(self, surface: pygame.Surface):
        if self.current_screen :
            self.current_screen.draw(surface)
        self._volume_slider.draw(surface)
