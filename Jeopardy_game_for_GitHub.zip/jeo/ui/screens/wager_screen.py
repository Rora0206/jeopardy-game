"""
Team B — ui/screens/wager_screen.py
Wager input screen with starfield BG and gold styling.
"""
import pygame
import config
from ui.ui_elements.text_input import TextInput
from ui.ui_elements.button import UIButton

def _sf(size, bold=False):
    try:    return pygame.font.SysFont(config.FONT_FAMILY, size, bold=bold)
    except: return pygame.font.Font(None, size)


class WagerScreen:
    def __init__(self, screen_manager):
        self.screen_manager = screen_manager
        self.player = None
        self.wager_purpose = "daily_double"
        self.max_wager = 0
        self.min_wager = config.WAGER_MIN
        self._error_msg = ""
        self._error_timer = 0.0

        cx = config.SCREEN_WIDTH // 2
        self.wager_input = TextInput(cx-160, 330, 320, 58, max_chars=6)
        self.submit_button = UIButton(
            cx - config.BUTTON_WIDTH // 2, 415,
            config.BUTTON_WIDTH, config.BUTTON_HEIGHT,
            "✔  Submit", self._on_submit_wager)

        self._font_title = _sf(config.FONT_SIZE_LARGE, bold=True)
        self._font_med = _sf(config.FONT_SIZE_MEDIUM)
        self._font_small = _sf(config.FONT_SIZE_SMALL)
        self._font_err = _sf(config.FONT_SIZE_SMALL, bold=True)

        self._bg = None
        try:
            raw = pygame.image.load(config.IMG_STARS_BG).convert()
            self._bg = pygame.transform.smoothscale(
                raw, (config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        except Exception:
            pass

        # prebuild static card surface
        self._card = pygame.Surface((560, 420), pygame.SRCALPHA)
        self._card.fill((5, 5, 40, 220))
        pygame.draw.rect(self._card, config.COLOR_BORDER,
                         self._card.get_rect(), 2, border_radius=14)

    def on_enter(self, player=None, wager_purpose="daily_double", max_wager=0, **kwargs):
        self.player        = player
        self.wager_purpose = wager_purpose
        self.max_wager     = max_wager
        self._error_msg    = ""
        self._error_timer  = 0.0
        self.wager_input.clear()

    def _on_submit_wager(self):
        text = self.wager_input.get_text().strip()
        if not text:
            self.show_error("Please enter a wager amount."); return
        try:
            amount = int(text)
        except ValueError:
            self.show_error("Please enter a valid number."); return
        game  = self.screen_manager.game
        valid = game.handle_wager(self.player, amount)
        if valid:
            self.wager_input.clear()
            rnd = game.get_current_round()
            self.screen_manager.switch_to(
                "question",
                question=rnd.current_question,
                is_final_jeopardy=(self.wager_purpose == "final_jeopardy"))
        else:
            self.show_error(f"Wager must be ${self.min_wager}–${self.max_wager}.")

    def show_error(self, msg):
        self._error_msg   = msg
        self._error_timer = 3.0

    def handle_events(self, events):
        mp = pygame.mouse.get_pos()
        self.submit_button.update(mp)
        for e in events:
            if e.type == pygame.KEYDOWN:
                result = self.wager_input.handle_key(e)
                if result is not None:
                    self._on_submit_wager()
            elif e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                self.submit_button.handle_click(e.pos)

    def update(self, events):
        dt = 1 / config.FPS
        self.wager_input.update(dt)
        if self._error_timer > 0:
            self._error_timer -= dt
            if self._error_timer <= 0:
                self._error_msg = ""
        self.handle_events(events)

    def draw(self, surface):
        if self._bg:
            surface.blit(self._bg, (0, 0))
        else:
            surface.fill(config.COLOR_BACKGROUND)

        cx = config.SCREEN_WIDTH // 2

        # center card
        surface.blit(self._card, (cx - 280, 80))

        # title
        label = "Final Jeopardy!" if self.wager_purpose == "final_jeopardy" else "Daily Double!"
        sh    = self._font_title.render(label, True, (0, 0, 0))
        ts    = self._font_title.render(label, True, config.COLOR_TEXT_GOLD)
        surface.blit(sh, sh.get_rect(centerx=cx + 2, centery=118 + 2))
        surface.blit(ts, ts.get_rect(centerx=cx, centery=118))

        # subtitle
        sub = self._font_small.render("Enter Your Wager", True, config.COLOR_TEXT_SILVER)
        surface.blit(sub, sub.get_rect(centerx=cx, centery=160))

        # gold divider
        pygame.draw.line(surface, (120, 90, 0), (cx - 200, 175), (cx + 200, 175), 1)

        # player info
        if self.player:
            nm = self._font_small.render(
                f"Player: {self.player.get_name()}", True, config.COLOR_TEXT_LIGHT)
            sc = self._font_med.render(
                f"Score: ${self.player.get_score():,}", True, config.COLOR_TEXT_GOLD)
            surface.blit(nm, nm.get_rect(centerx=cx, centery=200))
            surface.blit(sc, sc.get_rect(centerx=cx, centery=228))

        # range hint
        hint = self._font_small.render(
            f"Min: ${self.min_wager}   •   Max: ${self.max_wager:,}",
            True, config.COLOR_TEXT_SILVER)
        surface.blit(hint, hint.get_rect(centerx=cx, centery=284))

        self.wager_input.draw(surface)
        self.submit_button.draw(surface)

        if self._error_msg:
            err = self._font_err.render(self._error_msg, True, config.COLOR_TEXT_RED)
            surface.blit(err, err.get_rect(centerx=cx, centery=488))
