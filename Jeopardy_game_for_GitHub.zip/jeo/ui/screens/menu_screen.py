"""
Team B — ui/screens/menu_screen.py
Main menu with starfield background, glowing gold title, animated buttons.
"""
import sys, math, time, threading
import pygame
import config
from ui.ui_elements.button import UIButton


def _sf(size, bold=False):
    try:    return pygame.font.SysFont(config.FONT_FAMILY, size, bold=bold)
    except: return pygame.font.Font(None, size)


class MenuScreen:
    def __init__(self, screen_manager):
        self.screen_manager = screen_manager
        cx = config.SCREEN_WIDTH // 2

        self.play_button = UIButton(
            cx - config.BUTTON_WIDTH // 2, 300,
            config.BUTTON_WIDTH, config.BUTTON_HEIGHT,
            "▶  Play", self._on_play_clicked,
        )
        self.quit_button = UIButton(
            cx - config.BUTTON_WIDTH // 2, 380,
            config.BUTTON_WIDTH, config.BUTTON_HEIGHT,
            "✕  Quit", self._on_quit_clicked,
        )

        self._font_title  = _sf(config.FONT_SIZE_TITLE, bold=True)
        self._font_sub    = _sf(config.FONT_SIZE_SMALL)
        self._font_footer = _sf(config.FONT_SIZE_TINY)

        # background
        self._bg = None
        try:
            raw = pygame.image.load(config.IMG_STARS_BG).convert()
            self._bg = pygame.transform.smoothscale(
                raw, (config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        except Exception:
            pass

        # glow bar
        self._glow = None
        try:
            raw2 = pygame.image.load(config.IMG_GLOW_BAR).convert_alpha()
            self._glow = pygame.transform.smoothscale(raw2, (700, 8))
        except Exception:
            pass

        self._start_time = time.time()

        # Pre-build title glow surface; only set_alpha each frame instead of
        # recreating + drawing an ellipse at 60 fps.
        self._title_glow_surf = pygame.Surface((600, 90), pygame.SRCALPHA)
        pygame.draw.ellipse(self._title_glow_surf, (255, 200, 0, 255),
                            self._title_glow_surf.get_rect())

        # Loading state
        self._loading = False
        self._load_error: str = ""
        self._load_thread: threading.Thread | None = None
        self._font_loading = _sf(config.FONT_SIZE_MEDIUM, bold=True)
        self._dots_time = 0.0

    def _on_play_clicked(self):
        if self._loading:
            return
        self._loading = True
        self._load_error = ""
        self._load_thread = threading.Thread(target=self._bg_start_game, daemon=True)
        self._load_thread.start()

    def _bg_start_game(self):
        """Run in background thread: generate questions then switch screen."""
        try:
            self.screen_manager.game.start_game()
            # Post a custom event back to main thread to trigger screen switch
            pygame.event.post(pygame.event.Event(pygame.USEREVENT, {"action": "go_board"}))
        except Exception as e:
            self._load_error = str(e)
            self._loading = False

    def _on_quit_clicked(self):
        pygame.quit(); sys.exit()

    def handle_events(self, events):
        mp = pygame.mouse.get_pos()
        self.play_button.update(mp)
        self.quit_button.update(mp)
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                self.play_button.handle_click(mp)
                self.quit_button.handle_click(mp)

    def update(self, events):
        for e in events:
            if e.type == pygame.USEREVENT and getattr(e, "action", "") == "go_board":
                self._loading = False
                self.screen_manager.switch_to("board")
                return
        if not self._loading:
            self.handle_events(events)

    def draw(self, surface):
        # background
        if self._bg:
            surface.blit(self._bg, (0, 0))
        else:
            surface.fill(config.COLOR_BACKGROUND)

        cx = config.SCREEN_WIDTH // 2
        t  = time.time() - self._start_time

        # pulsing title glow — update alpha only, no Surface allocation
        pulse = 0.5 + 0.5 * math.sin(t * 2.0)
        glow_alpha = int(40 + pulse * 60)
        self._title_glow_surf.set_alpha(glow_alpha)
        surface.blit(self._title_glow_surf, (cx - 300, 68))

        # title shadow
        shadow = self._font_title.render("JEOPARDY!", True, (0, 0, 0))
        surface.blit(shadow, shadow.get_rect(centerx=cx + 3, centery=115 + 3))
        # title
        title = self._font_title.render("JEOPARDY!", True, config.COLOR_TEXT_GOLD)
        surface.blit(title, title.get_rect(centerx=cx, centery=115))

        # glow bar under title
        if self._glow:
            surface.blit(self._glow, (cx - 350, 148))
        else:
            pygame.draw.line(surface, (255, 200, 0), (cx - 200, 148), (cx + 200, 148), 2)

        # subtitle
        sub = self._font_sub.render("A Python x Pygame Quiz Game", True, config.COLOR_TEXT_SILVER)
        surface.blit(sub, sub.get_rect(centerx=cx, centery=175))

        if self._loading:
            # Show animated loading indicator instead of buttons
            dots = "." * (int(t * 2) % 4)
            msg = f"Loading questions{dots}"
            ls = self._font_loading.render(msg, True, config.COLOR_TEXT_GOLD)
            surface.blit(ls, ls.get_rect(centerx=cx, centery=350))
            if self._load_error:
                err_s = self._font_sub.render(f"Error: {self._load_error}", True, (220, 80, 80))
                surface.blit(err_s, err_s.get_rect(centerx=cx, centery=390))
        else:
            self.play_button.draw(surface)
            self.quit_button.draw(surface)

        # footer
        foot = self._font_footer.render(
            "Powered by Azure OpenAI  -  AIST 1110", True, (80, 80, 110))
        surface.blit(foot, foot.get_rect(centerx=cx, centery=config.SCREEN_HEIGHT - 20))
