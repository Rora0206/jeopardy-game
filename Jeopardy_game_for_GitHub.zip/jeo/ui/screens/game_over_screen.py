"""
Team B — ui/screens/game_over_screen.py
Final rankings with podium-style display, confetti-like gold accent, Play Again / Quit.
"""
import sys, math, time
import pygame
import config
from ui.ui_elements.button import UIButton


def _sf(size, bold=False):
    try:    return pygame.font.SysFont(config.FONT_FAMILY, size, bold=bold)
    except: return pygame.font.Font(None, size)


_MEDALS     = ["🥇 1st", "🥈 2nd", "🥉 3rd"]
_RANK_COLORS = [(255, 215,  0), (192, 192, 192), (205, 127,  50)]


class GameOverScreen:
    def __init__(self, screen_manager):
        self.screen_manager = screen_manager
        cx = config.SCREEN_WIDTH // 2

        self.play_again_button = UIButton(
            cx - config.BUTTON_WIDTH - 16, 545,
            config.BUTTON_WIDTH, config.BUTTON_HEIGHT,
            "▶  Play Again", self._on_play_again)
        self.quit_button = UIButton(
            cx + 16, 545,
            config.BUTTON_WIDTH, config.BUTTON_HEIGHT,
            "✕  Quit", self._on_quit)

        self._font_title  = _sf(config.FONT_SIZE_TITLE, bold=True)
        self._font_winner = _sf(config.FONT_SIZE_LARGE,  bold=True)
        self._font_rank   = _sf(config.FONT_SIZE_MEDIUM)
        self._font_small  = _sf(config.FONT_SIZE_SMALL)

        self._bg = None
        try:
            raw = pygame.image.load(config.IMG_STARS_BG).convert()
            self._bg = pygame.transform.smoothscale(
                raw, (config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        except Exception:
            pass

        self._glow = None
        try:
            raw2 = pygame.image.load(config.IMG_GLOW_BAR).convert_alpha()
            self._glow = pygame.transform.smoothscale(raw2, (700, 8))
        except Exception:
            pass

        self._start_time = time.time()

    def _on_play_again(self):
        self.screen_manager.game.reset_game()
        self.screen_manager.switch_to("menu")

    def _on_quit(self):
        pygame.quit(); sys.exit()

    def handle_events(self, events):
        mp = pygame.mouse.get_pos()
        self.play_again_button.update(mp)
        self.quit_button.update(mp)
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                self.play_again_button.handle_click(mp)
                self.quit_button.handle_click(mp)

    def update(self, events):
        self.handle_events(events)

    def draw(self, surface):
        if self._bg:
            surface.blit(self._bg, (0, 0))
        else:
            surface.fill(config.COLOR_BACKGROUND)

        cx = config.SCREEN_WIDTH // 2
        t = time.time() - self._start_time

        # title 
        pulse = 0.5 + 0.5 * math.sin(t * 2.2)
        glow_a = int(30 + pulse * 50)
        glow_s = pygame.Surface((500, 80), pygame.SRCALPHA)
        pygame.draw.ellipse(glow_s, (255, 200, 0, glow_a), glow_s.get_rect())
        surface.blit(glow_s, (cx - 250, 20))

        sh = self._font_title.render("GAME OVER", True, (0, 0, 0))
        ts = self._font_title.render("GAME OVER", True, config.COLOR_TEXT_GOLD)
        surface.blit(sh, sh.get_rect(centerx=cx + 2, centery=55 + 2))
        surface.blit(ts, ts.get_rect(centerx=cx, centery=55))

        if self._glow:
            surface.blit(self._glow, (cx - 350, 88))

        # winner 
        game = self.screen_manager.game
        rankings = game.get_final_rankings()
        if rankings:
            winner = rankings[0]
            w_txt = f"Winner: {winner.get_name()}!"
            w_sh = self._font_winner.render(w_txt, True, (0, 0, 0))
            w_s = self._font_winner.render(w_txt, True, (255, 240, 80))
            surface.blit(w_sh, w_sh.get_rect(centerx=cx + 2, centery=122 + 2))
            surface.blit(w_s,  w_s.get_rect(centerx=cx, centery=122))

        #rankings card 
        card_h = min(len(rankings), 3) * 80 + 20
        card   = pygame.Surface((560, card_h), pygame.SRCALPHA)
        card.fill((5, 5, 40, 210))
        pygame.draw.rect(card, config.COLOR_BORDER, card.get_rect(), 2, border_radius=12)
        surface.blit(card, (cx - 280, 148))

        for i, player in enumerate(rankings[:3]):
            medal  = _MEDALS[i] if i < len(_MEDALS) else f"{i+1}th"
            color  = _RANK_COLORS[i] if i < len(_RANK_COLORS) else config.COLOR_TEXT_LIGHT
            rank_y = 148 + i * 80 + 40
            txt    = f"{medal}   {player.get_name()}   ${player.get_score():,}"
            # rank card row bg
            row_bg = pygame.Surface((556, 60), pygame.SRCALPHA)
            row_bg.fill((*(c//3 for c in color), 25))
            surface.blit(row_bg, (cx - 278, rank_y - 25))
            sh = self._font_rank.render(txt, True, (0, 0, 0))
            rs = self._font_rank.render(txt, True, color)
            surface.blit(sh, sh.get_rect(centerx=cx + 1, centery=rank_y + 1))
            surface.blit(rs, rs.get_rect(centerx=cx, centery=rank_y))

        self.play_again_button.draw(surface)
        self.quit_button.draw(surface)
