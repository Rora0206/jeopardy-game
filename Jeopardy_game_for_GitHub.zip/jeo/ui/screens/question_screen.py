import pygame
import config
from ui.ui_elements.button import UIButton


def _sf(size, bold=False):
    try:    return pygame.font.SysFont(config.FONT_FAMILY, size, bold=bold)
    except: return pygame.font.Font(None, size)


class QuestionScreen:
    def __init__(self, screen_manager):
        self.screen_manager = screen_manager
        self.question = None
        self.is_final_jeopardy= False
        self.timer_seconds = config.TIMER_DURATION
        self.selected_answer = None
        self._answer_buttons: list[UIButton] = []
        self._result_display = ""
        self._result_timer= 0.0

        self._font_clue = _sf(config.FONT_SIZE_MEDIUM, bold=True)
        self._font_cat = _sf(config.FONT_SIZE_SMALL)
        self._font_timer = _sf(config.FONT_SIZE_MEDIUM, bold=True)
        self._font_result= _sf(config.FONT_SIZE_LARGE, bold=True)

        self._bg = None
        try:
            raw = pygame.image.load(config.IMG_STARS_BG).convert()
            self._bg = pygame.transform.smoothscale(
                raw, (config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        except Exception:
            pass

        self._cat_bg = pygame.Surface((config.SCREEN_WIDTH, 36), pygame.SRCALPHA)
        self._cat_bg.fill((10, 10, 60, 200))

        self._clue_panel = pygame.Surface((760, 230), pygame.SRCALPHA)
        self._clue_panel.fill((5, 5, 40, 200))
        pygame.draw.rect(self._clue_panel, config.COLOR_BORDER,
                         self._clue_panel.get_rect(), 2, border_radius=10)

        self._overlay = pygame.Surface(
            (config.SCREEN_WIDTH, config.SCREEN_HEIGHT), pygame.SRCALPHA)
        self._overlay.fill((0, 0, 0, 170))

    def on_enter(self, question=None, is_final_jeopardy=False, **kwargs):
        self.question = question
        self.is_final_jeopardy= is_final_jeopardy
        self.timer_seconds = config.TIMER_DURATION
        self.selected_answer = None
        self._result_display = ""
        self._result_timer= 0.0
        self._build_buttons()

    def _build_buttons(self):
        self._answer_buttons = []
        if not self.question:
            return
        btn_w= 600
        btn_h= 52
        start_y = 360
        cx = config.SCREEN_WIDTH // 2
        for i, choice in enumerate(self.question.choices):
            y = start_y + i * (btn_h + 12)
            btn = UIButton(
                cx - btn_w // 2, y, btn_w, btn_h,
                choice,
                callback=lambda idx=i: self._on_answer_selected(idx),
                font_size=config.FONT_SIZE_SMALL,
            )
            self._answer_buttons.append(btn)

    def _on_answer_selected(self, answer_idx):
        if self.selected_answer is not None:
            return
        self.selected_answer= answer_idx
        game = self.screen_manager.game
        player = game.get_current_player()
        correct = game.handle_answer(player, answer_idx)
        self._result_display = "correct" if correct else "incorrect"
        self._result_timer= 2.0

    def on_timer_expired(self):
        if self.selected_answer is not None:
            return
        self.selected_answer= -1
        game = self.screen_manager.game
        player = game.get_current_player()
        game.handle_answer(player, -1)
        self._result_display = "time_up"
        self._result_timer= 2.0

    def _transition_after_answer(self):
        state = self.screen_manager.game.get_game_state()
        self.screen_manager.switch_to("gameover" if state=="game_over" else "board")

    def handle_events(self, events):
        if self.selected_answer is not None:
            return
        mp = pygame.mouse.get_pos()
        for btn in self._answer_buttons:
            btn.update(mp)
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for btn in self._answer_buttons:
                    btn.handle_click(e.pos)

    def update(self, events):
        dt = 1 / config.FPS
        if self._result_timer > 0:
            self._result_timer -= dt
            if self._result_timer <= 0:
                self._transition_after_answer()
            return
        if self.selected_answer is None:
            self.timer_seconds -= dt
            if self.timer_seconds <= 0:
                self.on_timer_expired(); return
        self.handle_events(events)

    def draw(self, surface):
        if self._bg:
            surface.blit(self._bg, (0, 0))
        else:
            surface.fill(config.COLOR_BACKGROUND)

        game = self.screen_manager.game
        cx = config.SCREEN_WIDTH // 2

        if self.question and self.question.category:
            cat_txt = self.question.category.upper()
        else:
            cat_txt = game.get_round_name().upper()

        surface.blit(self._cat_bg, (0, 0))
        pygame.draw.line(surface, config.COLOR_BORDER, (0, 35), (config.SCREEN_WIDTH, 35), 1)
        cat_s = self._font_cat.render(cat_txt, True, config.COLOR_TEXT_GOLD)
        surface.blit(cat_s, cat_s.get_rect(centerx=cx, centery=18))

        if self.question and self.question.point_value > 0:
            badge_txt = f"  ${self.question.point_value:,}  "
            badge_s = self._font_cat.render(badge_txt, True, config.COLOR_TEXT_DARK)
            badge_r = badge_s.get_rect(centerx=cx, centery=60)
            pygame.draw.rect(surface, config.COLOR_TEXT_GOLD,
                             badge_r.inflate(6, 6), border_radius=6)
            surface.blit(badge_s, badge_r)

        surface.blit(self._clue_panel, (70, 75))
        if self.question:
            self._draw_wrapped(surface, self.question.clue,
                               self._font_clue, config.COLOR_TEXT_LIGHT,
                               90, 92, 720)

        bar_x, bar_y, bar_w, bar_h = 50, 320, config.SCREEN_WIDTH - 100, 16
        pct = max(0, self.timer_seconds / config.TIMER_DURATION)
        pygame.draw.rect(surface, (30, 30, 30), (bar_x, bar_y, bar_w, bar_h), border_radius=8)
        if pct > 0.4:
            bar_col = config.COLOR_TIMER_GREEN
        elif pct > 0.2:
            bar_col = config.COLOR_TIMER_YELLOW
        else:
            bar_col = config.COLOR_TIMER_RED
        fill_w= int(bar_w * pct)
        if fill_w > 0:
            pygame.draw.rect(surface, bar_col, (bar_x, bar_y, fill_w, bar_h), border_radius=8)
        pygame.draw.rect(surface, (80, 80, 80), (bar_x, bar_y, bar_w, bar_h), 1, border_radius=8)
        timer_s = self._font_timer.render(f"{int(self.timer_seconds)}s", True, config.COLOR_TEXT_LIGHT)
        surface.blit(timer_s, timer_s.get_rect(right=bar_x + bar_w, centery=bar_y - 8))

        if self._result_display == "":
            for btn in self._answer_buttons:
                btn.draw(surface)

        if self._result_display:
            self._draw_result_overlay(surface)

        player = game.get_current_player()
        if player:
            p_s = self._font_cat.render(
                f"{player.get_name()}  •  ${player.get_score():,}", True, config.COLOR_TEXT_SILVER)
            surface.blit(p_s, p_s.get_rect(right=config.SCREEN_WIDTH - 16,
                                             centery=config.SCREEN_HEIGHT - 18))

    @staticmethod
    def _sanitize(text: str) -> str:
        replacements = {
            "\u2018": "'", "\u2019": "'",
            "\u201c": '"', "\u201d": '"',
            "\u2013": "-", "\u2014": "-",
            "\u2026": "...",
            "\u00e9": "e", "\u00e8": "e",
            "\u00e0": "a", "\u00e2": "a",
            "\u00f4": "o", "\u00fb": "u",
        }
        for src, dst in replacements.items():
            text = text.replace(src, dst)
        text = text.encode("ascii", errors="replace").decode("ascii").replace("?", " ")
        return text

    def _draw_wrapped(self, surface, text, font, color, x, y, max_width):
        text = self._sanitize(text)
        words = text.split()
        line= ""
        cy= y
        lh = font.get_linesize() + 4
        for word in words:
            test = (line + " " + word).strip()
            if font.size(test)[0] <= max_width:
                line = test
            else:
                if line:
                    s = font.render(line, True, color)
                    surface.blit(s, s.get_rect(centerx=x + max_width//2, y=cy))
                    cy +=lh
                line= word
        if line:
            s = font.render(line, True, color)
            surface.blit(s, s.get_rect(centerx=x + max_width//2, y=cy))

    def _draw_result_overlay(self, surface):
        cx = config.SCREEN_WIDTH // 2
        cy = config.SCREEN_HEIGHT // 2
        surface.blit(self._overlay, (0, 0))
        color_map = {
            "correct": config.COLOR_TEXT_GREEN,
            "incorrect": config.COLOR_TEXT_RED,
            "time_up": config.COLOR_TIMER_YELLOW,
        }
        label_map = {"correct": "CORRECT!", "incorrect": "INCORRECT!", "time_up": "TIME'S UP!"}
        color = color_map.get(self._result_display, config.COLOR_TEXT_LIGHT)
        msg = label_map.get(self._result_display, "")
        shadow = self._font_result.render(msg, True, (0, 0, 0))
        text = self._font_result.render(msg, True, color)
        surface.blit(shadow, shadow.get_rect(centerx=cx + 2, centery=cy - 18))
        surface.blit(text, text.get_rect(centerx=cx, centery=cy - 20))
        if self.question and self._result_display != "correct":
            ans_s = self._font_cat.render(
                f"Answer: {self._sanitize(self.question.get_correct_choice())}",
                True, config.COLOR_TEXT_LIGHT)
            surface.blit(ans_s, ans_s.get_rect(centerx=cx, centery=cy + 26))
