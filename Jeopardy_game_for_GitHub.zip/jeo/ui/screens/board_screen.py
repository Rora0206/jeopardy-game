import threading
import time
import pygame
import config
from ui.ui_elements.board_tile import BoardTileUI


def _sf(size, bold=False):
    try:    return pygame.font.SysFont(config.FONT_FAMILY, size, bold=bold)
    except: return pygame.font.Font(None, size)


class BoardScreen:
    def __init__(self, screen_manager):
        self.screen_manager= screen_manager
        self.tiles_ui: list[list] = [[None]*3 for _ in range(3)]
        self._board_built= False

        self._font_title = _sf(config.FONT_SIZE_LARGE, bold=True)
        self._font_med = _sf(config.FONT_SIZE_MEDIUM, bold=True)
        self._font_small= _sf(config.FONT_SIZE_SMALL)
        self._font_cat = _sf(config.FONT_SIZE_TINY, bold=True)

        self._bg = None
        try:
            raw = pygame.image.load(config.IMG_STARS_BG).convert()
            self._bg = pygame.transform.smoothscale(
                raw, (config.SCREEN_WIDTH, config.SCREEN_HEIGHT))
        except Exception:
            pass

        self._cat_bg_surf = pygame.Surface(
            (config.TILE_WIDTH, config.CATEGORY_ROW_H), pygame.SRCALPHA)
        self._cat_bg_surf.fill((10, 10, 70, 210))

        self._hl_surf: pygame.Surface | None = None

        self._transitioning= False
        self._transition_error= ""
        self._font_loading = _sf(config.FONT_SIZE_MEDIUM, bold=True)
        self._loading_start= 0.0

    def on_enter(self, **kwargs):
        self._rebuild_tiles()

    def _rebuild_tiles(self):
        game = self.screen_manager.game
        rnd = game.get_current_round()
        if rnd is None or rnd.board is None:
            self._board_built= False
            return
        for r in range(3):
            for c in range(3):
                x = config.BOARD_OFFSET_X + c * (config.TILE_WIDTH + config.TILE_MARGIN)
                y = config.BOARD_OFFSET_Y + r * (config.TILE_HEIGHT + config.TILE_MARGIN)
                tile = rnd.board.get_tile(r, c)
                self.tiles_ui[r][c] = BoardTileUI(tile, x, y,
                                                   config.TILE_WIDTH, config.TILE_HEIGHT)
        self._board_built= True

    def handle_events(self, events):
        game = self.screen_manager.game
        current = game.get_current_player()
        if current is None or not current.is_player_human():
            return
        mp = pygame.mouse.get_pos()
        for r in range(3):
            for c in range(3):
                ui = self.tiles_ui[r][c]
                if ui:
                    ui.update_hover(mp)
        for e in events:
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                for r in range(3):
                    for c in range(3):
                        ui = self.tiles_ui[r][c]
                        if ui and ui.handle_click(e.pos):
                            self._on_tile_clicked(r, c)
                            return

    def _on_tile_clicked(self, row, col):
        game = self.screen_manager.game
        player = game.get_current_player()
        result = game.handle_tile_selection(player, row, col)
        state = game.get_game_state()
        if state == "waiting_for_wager":
            rnd = game.get_current_round()
            board = rnd.board
            remaining = board.get_unanswered_tiles() if board else []
            max_board= max((t.point_value for t in remaining), default=0)
            max_wager = max(player.get_score(), max_board)
            self.screen_manager.switch_to(
                "wager", player=player,
                wager_purpose="daily_double", max_wager=max_wager)
        elif state == "answering_question" and result is not None:
            rnd = game.get_current_round()
            self.screen_manager.switch_to(
                "question", question=result,
                is_final_jeopardy=(rnd.round_type == "final"))

    def update(self, events):
        game = self.screen_manager.game
        state = game.get_game_state()

        if self._transitioning:
            for e in events:
                if e.type == pygame.USEREVENT and getattr(e, "action", "") == "board_transition_done":
                    self._transitioning= False
                    result = getattr(e, "result", "board")
                    if result == "gameover":
                        self.screen_manager.switch_to("gameover")
                    elif result == "final":
                        self._handle_final_jeopardy_flow(game)
                    else:
                        self._rebuild_tiles()
            return

        if state == "round_transition":
            self._transitioning= True
            self._transition_error= ""
            self._loading_start= time.time()
            t = threading.Thread(target=self._bg_advance_round, daemon=True)
            t.start()
            return

        if state == "game_over":
            self.screen_manager.switch_to("gameover"); return

        if not self._board_built:
            self._rebuild_tiles()

        self.handle_events(events)

    def _bg_advance_round(self):
        try:
            game = self.screen_manager.game
            advanced = game.advance_to_next_round()
            if not advanced or game.is_game_over():
                pygame.event.post(pygame.event.Event(
                    pygame.USEREVENT, {"action": "board_transition_done", "result": "gameover"}))
                return
            rnd = game.get_current_round()
            if rnd.round_type == "final":
                pygame.event.post(pygame.event.Event(
                    pygame.USEREVENT, {"action": "board_transition_done", "result": "final"}))
            else:
                pygame.event.post(pygame.event.Event(
                    pygame.USEREVENT, {"action": "board_transition_done", "result": "board"}))
        except Exception as e:
            self._transition_error= str(e)
            self._transitioning= False

    def _handle_final_jeopardy_flow(self, game):
        rnd = game.get_current_round()
        eligible = rnd.get_eligible_players_final()
        if not eligible:
            self.screen_manager.switch_to("gameover"); return
        human = next((p for p in eligible if p.is_player_human()), None)
        if human:
            self.screen_manager.switch_to(
                "wager", player=human,
                wager_purpose="final_jeopardy",
                max_wager=max(human.get_score(), 0))
        else:
            for p in eligible:
                game.run_ai_turn()
            self.screen_manager.switch_to("gameover")

    def draw(self, surface):
        if self._bg:
            surface.blit(self._bg, (0, 0))
        else:
            surface.fill(config.COLOR_BACKGROUND)

        if self._transitioning:
            cx= config.SCREEN_WIDTH // 2
            cy= config.SCREEN_HEIGHT // 2
            t = time.time() - self._loading_start
            dots = "." * (int(t * 2) % 4)
            msg = f"Loading next round{dots}"
            ls = self._font_loading.render(msg, True, config.COLOR_TEXT_GOLD)
            surface.blit(ls, ls.get_rect(centerx=cx, centery=cy))
            if self._transition_error:
                es = self._font_loading.render(
                    f"Error: {self._transition_error}", True, (220, 80, 80))
                surface.blit(es, es.get_rect(centerx=cx, centery=cy + 44))
            return

        game = self.screen_manager.game

        pygame.draw.rect(surface, (5, 5, 50), (0, 0, config.SCREEN_WIDTH, 46))
        pygame.draw.line(surface, config.COLOR_BORDER,
                         (0, 45), (config.SCREEN_WIDTH, 45), 1)

        rname = game.get_round_name()
        t_surf = self._font_title.render(rname, True, config.COLOR_TEXT_GOLD)
        sh = self._font_title.render(rname, True, (0, 0, 0))
        cx= config.SCREEN_WIDTH // 2
        surface.blit(sh, sh.get_rect(centerx=cx + 2, centery=22 + 2))
        surface.blit(t_surf, t_surf.get_rect(centerx=cx, centery=22))

        self._draw_scoreboard(surface, game)

        rnd = game.get_current_round()
        if rnd and rnd.board and self._board_built:
            self._draw_category_row(surface, rnd)

        if self._board_built:
            for r in range(3):
                for c in range(3):
                    ui = self.tiles_ui[r][c]
                    if ui:
                        ui.draw(surface)

        current = game.get_current_player()
        if current:
            label = f"Turn: {current.get_name()}"
            turn_s = self._font_small.render(label, True, config.COLOR_TEXT_LIGHT)
            surface.blit(turn_s, (18, config.SCREEN_HEIGHT - 28))

    def _draw_category_row(self, surface, rnd):
        cat_y = config.BOARD_OFFSET_Y - config.CATEGORY_ROW_H - 4
        for c in range(config.BOARD_COLS):
            x = config.BOARD_OFFSET_X + c * (config.TILE_WIDTH + config.TILE_MARGIN)
            rect = pygame.Rect(x, cat_y, config.TILE_WIDTH, config.CATEGORY_ROW_H)
            surface.blit(self._cat_bg_surf, rect.topleft)
            pygame.draw.rect(surface, config.COLOR_BORDER, rect, 1, border_radius=4)
            cat_name= ""
            for r in range(3):
                tile = rnd.board.get_tile(r, c)
                if tile and hasattr(tile, 'question') and tile.question and tile.question.category:
                    cat_name = tile.question.category.upper()
                    break
            if not cat_name:
                cat_name = f"CAT {c+1}"
            cs = self._font_cat.render(cat_name, True, config.COLOR_TEXT_GOLD)
            cr = cs.get_rect(center=rect.center)
            surface.blit(cs, cr)

    def _draw_scoreboard(self, surface, game):
        players = game.players
        panel_y= 48
        panel_h = config.SCOREBOARD_HEIGHT - 10
        panel_w = config.SCREEN_WIDTH - 40
        pygame.draw.rect(surface, (5, 5, 45), (20, panel_y, panel_w, panel_h), border_radius=8)
        pygame.draw.rect(surface, config.COLOR_BORDER,
                         (20, panel_y, panel_w, panel_h), 2, border_radius=8)
        col_w = panel_w // len(players)
        hl_w = col_w - 4
        hl_h= panel_h - 4
        if self._hl_surf is None or self._hl_surf.get_size() != (hl_w, hl_h):
            self._hl_surf = pygame.Surface((hl_w, hl_h), pygame.SRCALPHA)
            self._hl_surf.fill((255, 215, 0, 20))
        for i, p in enumerate(players):
            x = 20 + i * col_w + col_w // 2
            if p == game.get_current_player():
                surface.blit(self._hl_surf, (20 + i * col_w + 2, panel_y + 2))
            name_s = self._font_small.render(p.get_name(), True, config.COLOR_TEXT_LIGHT)
            score_s = self._font_med.render(f"${p.get_score():,}", True, config.COLOR_TEXT_GOLD)
            surface.blit(name_s, name_s.get_rect(centerx=x, centery=panel_y + 28))
            surface.blit(score_s, score_s.get_rect(centerx=x, centery=panel_y + 62))
            if i < len(players) - 1:
                div_x = 20 + (i + 1) * col_w
                pygame.draw.line(surface, (60, 60, 100),
                                 (div_x, panel_y + 10), (div_x, panel_y + panel_h - 10))
